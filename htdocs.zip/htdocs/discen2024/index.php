<?php
/*
BISMILLAAHIRRAHMAANIRRAHIIM - 알라의 이름으로, 가장 자비롭고 가장 자애로운
================================================================================
파일명  : index.php
목적    : 
작성일  : 2017-05-05
마지막 수정일 : 2020-07-30
작성자  : cahya dsn
================================================================================
이 프로그램은 자유 소프트웨어입니다; 당신은 이 소프트웨어를 재배포하고/하거나 수정할 수 있습니다 
GNU 일반 공중 라이선스(GNU General Public License) 하에 자유 소프트웨어 재단이 발표한 버전 2 또는 (선택에 따라) 
이후 버전의 조건을 따릅니다.

이 프로그램은 유용하리라는 희망으로 배포되지만, 어떠한 보증도 없이 제공됩니다; 
특정 목적에 대한 적합성 또는 상업성에 대한 묵시적인 보증을 포함하여, 보증이 없습니다. 
자세한 사항은 GNU 일반 공중 라이선스를 참조하십시오.

저작권 (c) 2017-2020 by cahya dsn; cahyadsn@gmail.com
================================================================================
*/
session_start();
include 'inc/config.php';
$c=isset($_SESSION['c'])?$_SESSION['c']:(isset($_GET['c'])?$_GET['c']:'indigo');
$page=isset($_SESSION['page'])?$_SESSION['page']:0;
$num_perpage=5;
$_SESSION['author'] = 'cahyadsn';
$_SESSION['ver']    = sha1(rand());
$version    = '0.7';                  //<-- 버전 번호
header('Expires: '.date('r'));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');
//-- 데이터베이스에서 쿼리 가져오기
$sql='SELECT * FROM disc_personalities ORDER BY no ASC';
$result=$db->query($sql);
$data=$x=array();
$no=0;
while($row=$result->fetch_object()){
   if($no!=$row->no){
      $no=$row->no;
      $x[$no]=array();
   }
   $x[$no][]=$row;
}
// 디버깅을 위해 셔플 비활성화
if ( empty( $_GET['dbg'] ) ) {
   shuffle($x);     //<-- 질문 데이터 셔플
}
$data=array();
foreach($x as $dt){
  if ( empty( $_GET['dbg'] ) ) {
    shuffle($dt); //<-- 각 질문의 항목을 셔플
  }
  foreach($dt as $d){
   $data[]=$d;
  }
}
$terms=json_encode($data);
//-- 레이아웃 설정
$show_mark   = 0;                       //<-- 표시:1 또는 숨기기:0 마커
$cols      = 4;                       //<-- 열의 수 (1..4)
$rows        = count($data)/(4*$cols); //<-- 행의 수
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <title>DiSC 성격 테스트 <?php echo $version;?> </title>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta http-equiv="content-language" content="ko" />
  <meta name="author" content="Cahya DSN" />
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
  <meta name="keywords" content="DiSC, 성격, 테스트" />
  <meta name="description" content="DiSC 성격 테스트 ver <?php echo $version;?> created by cahya dsn" />
  <meta name="robots" content="index, follow" />
  <link rel="shortcut icon" href="<?php echo _ASSET;?>img/favicon.ico" type="image/x-icon">
  <?php if(defined('_ISONLINE') && _ISONLINE):?>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-<?php echo $c;?>.css" media="all" id="disc_css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
  <?php else:?>
  <link rel="stylesheet" href="<?php echo _ASSET;?>css/w3/w3.css">
  <link rel="stylesheet" href="<?php echo _ASSET;?>css/w3/w3-theme-<?php echo $c;?>.css" media="all" id="disc_css">
  <script src="<?php echo _ASSET;?>js/jquery.min.js"></script>
  <?php endif;?>
  <style>body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
  .w3-closebtn {text-decoration: none;float: right;font-size: 24px;font-weight: bold;color: inherit;} .w16left{padding-left:16px !important;}</style>
</head>
<body>
<div class="w3-top">
  <div class="w3-bar w3-theme-d5">
    <span class="w3-bar-item"># DiSC v<?php echo $version;?></span>
    <a href="#" class="w3-bar-item w3-button">홈</a>
      <div class="w3-dropdown-hover">
        <button class="w3-button">테마</button>
        <div class="w3-dropdown-content w3-white w3-card-4" id="theme">
            <?php
            $color=array("black","brown","pink","orange","amber","lime","green","teal","purple","indigo","blue","cyan");
            foreach($color as $c){
               echo "<a href='#' class='w3-bar-item w3-button w3-{$c} color' data-value='{$c}'> </a>";
            }
            ?>   
         </div>
      </div>
   </div>
</div>  
<div class="w3-container">
  <form method='post' action='result.php' name="disc">
    <div class="w3-card-4">
      <div class='w3-container'>
        <h2>&nbsp;</h2>
        <h2>DiSC 성격 테스트</h2>
        <div class="w3-row">
          <div class="w3-col s12">
          <p>
            DiSC 성격 테스트의 목적은 자신과 타인을 이해하는 데 도움을 주는 것입니다. 이 프로파일은 인간 행동을 이해하는 틀을 제공하며, 자신의 독특한 행동 패턴에 대한 지식을 증가시킵니다. 이 실용적인 접근법의 목표는 성공을 보장하는 환경을 만드는 데 도움을 주는 것입니다. 동시에, 다른 행동 스타일에 의해 요구되는 다양한 동기 부여 환경을 이해하게 될 것입니다. 세 가지 해석 단계는 일반에서 구체적으로 진행되어 사람들을 이해하기 위한 DiSC 행동 차원의 접근법을 마스터하는 데 도움을 줍니다.
           </p>
         <div class="w3-container w3-theme-d2 w3-section">
            <span onclick="this.parentElement.style.display='none'" class="w3-closebtn">x</span>
            <h3>사용법</h3>
            <p>각 28개의 단어 그룹에서 <b>가장</b> 적합한 것과 <b>가장 덜</b> 적합한 것을 선택하세요.</p>
         </div>
          </div>
        </div>
        <?php for($i=0;$i<$rows;++$i):?>
        <div class="w3-row">
          <?php for($j=0;$j<$cols;++$j):?>
          <div class="w3-col m6 l3">
         <?php if($i*$cols+$j<28) :?>
         <table class='w3-table'>
              <thead>
              <tr class='w3-theme-d3'>
                <th>번호</th>
                <th>항목</th>
                <th>가장 적합</th>
                <th>가장 덜 적합</th>
              </tr>
              </thead>
              <tbody>
              <?php
              if(isset($_GET['auto'])){
                $m=rand(0,3);
                $l=rand(0,3);
                $l=$l==$m?(($m+1)%4):$l;
              } else{
                $m=$l='a';
              }
              for($n=0;$n<4;++$n): 
            $idx=($i*$cols+$j)*4+$n;
                $num=$i*$cols+$j+1;
                echo '<tr'.($num%2==0?' class="w3-theme-l3"':'').'>';
              ?>
                  <?php if($n==0):?>
                  <th rowspan='4'><?php echo $num;?></th>
                  <?php endif;?>
                  <td class='w16left'><?php echo $data[$idx]->term; ?></td>
                  <td><input type='radio' class='w3-radio' id='m_<?php echo "{$num}_{$n}";?>' name='m[<?php echo $num;?>]' value='<?php echo $data[$idx]->most;?>' required<?php echo ($m===$n?' checked':'');?>></td>
                  <td><input type='radio' class='w3-radio' id='l_<?php echo "{$num}_{$n}";?>' name='l[<?php echo $num;?>]' value='<?php echo $data[$idx]->least;?>' required<?php echo ($l===$n?' checked':'');?>></td>
                </tr>
              <?php endfor;?>
              </tbody>
            </table>
         <?php endif;?>
          </div>
          <?php endfor;?>
        </div>
        <?php endfor;?>
        <div class="w3-row">
          <div class="w3-col s12">
            <h6>&nbsp;</h6>
            <input type='submit' value='처리' class='w3-button w3-round-large w3-theme-d1 w3-right w3-margin-8'/> 
          </div>
        </div>
        <h2>&nbsp;</h2>
      </div>
    </div>
  </form>
</div>
<div class="w3-bottom">
   <div class="w3-bar w3-theme-d4 w3-center w3-padding">
      DiSC 성격 테스트 v<?php echo $version;?> 저작권 &copy; 2017<?php echo date('Y')>2017?'-'.date('Y'):'';?> by <a href="mailto:cahyadsn@gmail.com">cahya dsn</a><br />
   </div>
</div>
<div id="warning" class="w3-modal">
  <div class="w3-modal-content">
    <header class="w3-container w3-red"> 
      <span onclick="document.getElementById('warning').style.display='none'" class="w3-closebtn w3-hover-red w3-container w3-padding-8 w3-display-topright" title="모달 닫기">&times;</span>
      <h2>경고</h2>
    </header>
    <div class="w3-container">
      <p id='msg'></p>
    </div>
    <footer class="w3-container w3-border-top w3-padding-16 w3-light-grey">
      <a href='#' onclick="document.getElementById('warning').style.display='none'" class="w3-button w3-grey">닫기</a>
    </footer>
  </div>
</div>
<script src="<?php echo _ASSET;?>js/disc.v6.php?v=<?php echo md5(filemtime(_ASSET.'js/disc.v6.php'));?>"></script>     
</body>
</html>
