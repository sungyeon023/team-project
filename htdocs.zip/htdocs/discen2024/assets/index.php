copyright &copy; 2016 - <?php echo date('Y');?> cahyadsn
