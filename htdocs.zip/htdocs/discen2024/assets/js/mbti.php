<?php 
header("Content-type: text/javascript");
echo "var aset='../assets';";
?>
$('a.color').click(function(){
  var color=$(this).attr('data-value');
  document.getElementById('mbti_css').href=aset+'/css/w3-theme-'+color+'.css';
  $.post(aset+'/js/change.color.php',{'color':color});
});