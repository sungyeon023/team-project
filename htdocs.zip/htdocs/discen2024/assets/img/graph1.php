<?php
$c=isset($_GET['c'])?$_GET['c']:'black';
$g=isset($_GET['g'])?$_GET['g']:'I';
header('Content-type:image/svg+xml');
$s=array('black'=>'#333333','brown'=>'#553c33','pink'=>'#790C30','orange'=>'#b36b00','amber'=>'#826200','lime'=>'#96a41d','green'=>'#357a38','teal'=>'#00685d','purple'=>'#6d1b7b','indigo'=>'#2d397f','blue'=>'#00b9ff','cyan'=>'#005f6b');
$t=array('black'=>'#cccccc','brown'=>'#ac8375','pink'=>'#ea346f','orange'=>'#ffb74d','amber'=>'#e8af00','lime'=>'#cfdf48','green'=>'#5db861','teal'=>'#00ceb8','purple'=>'#b72dcf','indigo'=>'#5161c1','blue'=>'#0081f6','cyan'=>'#00bad1');

$intensity=array(1=>415,404.5,394,383.5,373,362.5,352,341.5,331,320.5,310,299.5,289,278.5,268,257.5,247,236.5,226,215.5,205,194.5,184,173.5,163,152.5,142,131.5);
$items=array('d'=>78.5,'i'=>138.5,'s'=>198.5,'c'=>258.5);
?>
<svg width="350" height="550" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
 <metadata id="metadata5">image/svg+xml</metadata>
 <metadata id="author">cahya dsn</metadata>
 <g class="layer">
  <title>DiSC Graph <?php echo $g;?></title>
  <g id="panel_top">
    <rect id="box_title" fill="<?php echo $s[$c];?>" x="20" y="15" width="310" height="35" stroke="<?php echo $s[$c];?>"/>
    <text id="title_text" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="170" y="40" font-size="24" font-family="Sans-serif" text-anchor="middle" xml:space="preserve" font-weight="bold">GRAPH <?php echo $g;?></text>
  </g>
  <g id="horizontal_line">
   <rect id="shadow_center" fill="<?php echo $t[$c];?>" stroke="#b3d2f2" x="18.38889" y="252.25" width="310" height="44"/>
   <?php for($i=0;$i<6;$i++):?>
   <line id="hline<?php echo $i+1;?>" fill="none" stroke="<?php echo $s[$c];?>" stroke-width="null" stroke-dasharray="5,5" stroke-linejoin="null" stroke-linecap="null" x1="25" y1="<?php echo (378.25-42*$i);?>" x2="320" y2="<?php echo (378.25-42*$i);?>"/>
   <?php endfor;?>
  </g>  
  <g id="panel_segment">
    <rect id="box_segment" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" x="20" y="428" width="310" height="44"/>
    <text id="txt_segment" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="445" x="300" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="#ffffff">SEGMENT</text>
    <text id="txt_numbers" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="460" x="300" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="#ffffff">NUMBERS</text>
    <rect id="block_d" fill="#ffffff" stroke="#ffffff" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="39" y="433" width="40" height="35"/>
    <rect id="block_i" fill="#ffffff" stroke="#ffffff" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="99" y="433" width="40" height="35"/>
    <rect id="block_s" fill="#ffffff" stroke="#ffffff" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="159" y="433" width="40" height="35"/>
    <rect id="block_c" fill="#ffffff" stroke="#ffffff" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="219" y="433" width="40" height="35"/>
    <text id="value_d" fill="#000000" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="60" y="458" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">7</text>
    <text id="value_i" fill="#000000" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="120" y="458" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">7</text>
    <text id="value_s" fill="#000000" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="180" y="458" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">7</text>
    <text id="value_c" fill="#000000" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="240" y="458" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">7</text>
  </g>
  <g id="panel_pattern">
    <rect id="box_pattern" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" x="20" y="488" width="310" height="44"/>
    <text id="txt_classical" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="505" x="300" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="#ffffff">CLASSICAL</text>
    <text id="txt_patterns" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="520" x="300" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="#ffffff">PATTERNS</text>
    <rect id="block_pattern" stroke="#ffffff" fill="#ffffff" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="39" y="493" width="220" height="35"/>
    <text id="value_pattern" fill="#000000" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="142.5" y="516" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">DEVELOPER</text>
    </g>
  <g id="segment_number">
    <text id="label_segment" font-weight="bold" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="110" x="310" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="<?php echo $s[$c];?>">segment</text>
    <rect id="segment_bar" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" x="308" y="118" width="22" height="301"/>
    <text id="segment1" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="405" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">1</text>
    <text id="segment2" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="362" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">2</text>
    <text id="segment3" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="319" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">3</text>
    <text id="segment4" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="276" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">4</text>
    <text id="segment5" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="233" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">5</text>
    <text id="segment6" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="190" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">6</text>
    <text id="segment7" fill="#ffffff" stroke="#b3d2f2" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="320" y="147" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve">7</text>
  </g>
  <g id="intensity_number">
    <text id="label_intensity" font-weight="bold" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="10" y="114" x="40" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="0" stroke="<?php echo $s[$c];?>" fill="<?php echo $s[$c];?>">intensity</text>
    <rect id="intensity_bar" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" x="20" y="118" width="15" height="301"/>
    <?php foreach($intensity as $k=>$v):?>
    <text id="intensity<?php echo $k;?>" xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="9" y="<?php echo $v;?>" x="26.5625" stroke-width="0" stroke="#000000" fill="#ffffff"><?php echo $k;?></text>
    <?php endforeach;?>
  </g>
  <g id="label">
    <path id="sign_d" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" d="m57.05901,77.941l23.45455,0l19.54545,21.55901l-19.54545,21.55901l-23.45455,0l0,-43.11803l0,0.00001z" transform="rotate(90 78.55901336669922,99.50000000000001) "/>
    <path id="sign_i" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" d="m117.05901,77.94097l23.45455,0l19.54545,21.55902l-19.54545,21.55901l-23.45455,0l0,-43.11802l0,-0.00001z" transform="rotate(90 138.55902099609378,99.49998474121095) "/>
    <path id="sign_s" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" d="m177.05901,77.94098l23.45455,0l19.54545,21.55902l-19.54545,21.55901l-23.45455,0l0,-43.11803z" transform="rotate(90 198.55900573730472,99.50000000000001) "/>
    <path id="sign_c" fill="<?php echo $s[$c];?>" stroke="<?php echo $s[$c];?>" stroke-width="null" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" d="m237.05901,77.941l23.45455,0l19.54545,21.55902l-19.54545,21.55901l-23.45455,0l0,-43.11803z" transform="rotate(90 258.5590209960938,99.50001525878909) "/>
    <text id="label_d" fill="#ffffff" stroke="#000000" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="77" y="100" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve" font-weight="bold">D</text>
    <text id="label_i" fill="#ffffff" stroke="#000000" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="137" y="100" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve" font-weight="bold">I</text>
    <text id="label_s" fill="#ffffff" stroke="#000000" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="197" y="100" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve" font-weight="bold">S</text>
    <text id="label_c" fill="#ffffff" stroke="#000000" stroke-width="0" stroke-dasharray="null" stroke-linejoin="null" stroke-linecap="null" x="257" y="100" font-size="20" font-family="Sans-serif" text-anchor="middle" xml:space="preserve" font-weight="bold">C</text>
    <rect id="bar_d" fill="<?php echo $s[$c];?>" x="77" y="118" width="3" height="300" stroke="<?php echo $s[$c];?>"/>
    <rect id="bar_i" fill="<?php echo $s[$c];?>" x="137" y="118" width="3" height="300" stroke="<?php echo $s[$c];?>"/>
    <rect id="bar_s" fill="<?php echo $s[$c];?>" x="197" y="118" width="3" height="300" stroke="<?php echo $s[$c];?>"/>
    <rect id="bar_c" fill="<?php echo $s[$c];?>" x="257" y="118" width="3" height="300" stroke="<?php echo $s[$c];?>"/>   
  </g>
  <g id="plot">
    <ellipse id="point_d" ry="5" rx="5" cy="184" cx="78.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="null" stroke="#b3d2f2" fill="#000000"/>
    <ellipse id="point_i" ry="5" rx="5" cy="142" cx="138.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="null" stroke="#b3d2f2" fill="#000000"/>
    <ellipse id="point_s" ry="5" rx="5" cy="173.5" cx="198.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="null" stroke="#b3d2f2" fill="#000000"/>
    <ellipse id="point_c" ry="5" rx="5" cy="236.5" cx="258.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="null" stroke="#b3d2f2" fill="#000000"/>
    <line id="line_di" y1="184" x1="78.5" y2="142" x2="138.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="3" stroke="#000205" fill="none"/>
    <line id="line_is" y1="142" x1="138.5" y2="173.5" x2="198.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="3" stroke="#000205" fill="none"/>
    <line id="line_sc" y1="173.5" x1="198.5" y2="236.5" x2="258.5" stroke-linecap="null" stroke-linejoin="null" stroke-dasharray="null" stroke-width="3" stroke="#000205" fill="none"/>
  </g>
 </g>
</svg>